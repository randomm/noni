# Intent
Last-confirmed: 2026-10-01
## Purpose
Ship the direction layer, and keep it a layer a person reads.
The order is the operator's own list, held in one committed file.
Every claim is a signal, never a lock, and the census is the arbiter.
A decision survives the session that made it or it is not a decision.
Plain files under git are the only truth this product keeps.
Metrics are derived from history, never reported by the thing measured.
The state root is named by one flag and read from that one answer.
Nothing here contacts a tracker: the issue number is only a number.
A refusal names the path, the state and the fix, in that order.
The census reports what it read and says what it could not read.
An unreadable file is never the same report as an absent one.
The brief is four blocks and a verdict, and it never writes.
A tool that could not read its input does not call the tree clean.
Every foreign message is scrubbed and bounded before it is printed.
Adapters live outside the core and the core stays viable without them.
A page that is true today and false in two hundred pull requests
is not documentation, so this file states principles, not steps.
Position in the queue is the operator's word and nobody else's.
An item is one idea, filed once, and its reason is never deleted.
Steering never answers for the operator; a question stays a question.
The intent file is read first at session start and capped at a page.
Superseding is the correction; the original record keeps its place.
Scripts exist only where an exit code has to be honest.
Two runs over one tree with one instant print the same bytes.
What is not required is not built.
## Principles
- the census is the arbiter
## Never
- no daemon, no database
## Ask first
- anything that costs money
